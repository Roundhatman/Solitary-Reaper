// I2C
#include <Wire.h>

// OLED Lib
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// BMP280 Lib
#include <BMP280_DEV.h>

// SPIFFS Lib
#include <FS.h>
#include <SPIFFS.h>

// GPS
#include <TinyGPS++.h>
#include <SoftwareSerial.h>

// WiFi
#include <WiFi.h>
#include <WiFiClient.h>
#include <WiFiAP.h>
#include <ESPAsyncWebServer.h>

// Globals
#define SCREEN_WIDTH    128
#define SCREEN_HEIGHT   64
#define SCREEN_ADDRESS  0x3C
#define BMP280_ADDRESS  0x76
#define MAG_ADDRESS     0x0D
#define RXPin           17
#define TXPin           16

// Buttons
#define BTN_MENU  13
#define BTN_NEXT  27
#define BTN_SELT  12

// Fatal Errors
#define OLED_ERR    0xE1
#define BMP_ERR     0xE2
#define SPIFFS_ERR  0xE3
#define FILE_ERR    0xE4
#define GPS_ERR     0xE5

// Objects
BMP280_DEV bmp280;
Adafruit_SSD1306 oled(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);
TinyGPSPlus gps;
SoftwareSerial gss(RXPin, TXPin);
AsyncWebServer server(80);

// Globals
float T, P, A, V, GA, LAT, LON, courseToTar;
uint8_t H, M, SAT, mnu, sel, wpPage;
uint64_t idx, AIR, lastDebounceTime;
hw_timer_t * timer = NULL;
volatile SemaphoreHandle_t timerSemaphore;
portMUX_TYPE timerMux = portMUX_INITIALIZER_UNLOCKED;
esp_sleep_wakeup_cause_t wakeup_reason;

// Functions
void dprint(char *, uint8_t, uint8_t, bool, uint16_t);
void errorHandler(uint8_t);
void initSleep(void);
void initI2C(void);
void displayWP(void);
