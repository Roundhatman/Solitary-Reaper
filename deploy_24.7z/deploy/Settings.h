//#define INTV            5000
#define TARGET_LAT      06.8092838
#define TARGET_LON      80.4992772
#define SLEEP_TIME      60*1000000
#define WORK_TIME       5*1000000
#define Threshold       40
#define TEMP_OFF        0.0
#define ALT_SEA         1013.4
#define ALT_OFF         0.0

const char * ssid = "∑oliταri Rәαρәr 3.1";
const char * pass = "bayaballa";

float wpPoints[][2] = {
  {6.712372, 79.907460},
  {6.927377, 79.843650},
  {6.854942, 79.903706},
  
  {6.850394, 79.908630},
  {6.723726, 79.960302},
  {6.708688, 79.956299}
};

char * wpNames[] = {
  "Panadura",
  "Galle Face",
  "NFC",
  
  "Boarding",
  "Bravo",
  "Alpha"
};

static const unsigned char PROGMEM swasthika[] =
{ 0b10011110,
  0b10010000,
  0b10010000,
  0b11111110,
  0b00010010,
  0b00010010,
  0b11110010 };

static const unsigned char PROGMEM battery[] = 
{ 0b00111000,
  0b01111100,
  0b01000100,
  0b01000100,
  0b01000100,
  0b01000100,
  0b01111100 };

static const unsigned char PROGMEM memory[] =
{ 0b01010100,
  0b11111110,
  0b01000100,
  0b11000110,
  0b01000100,
  0b11111110,
  0b01010100 };

static const unsigned char PROGMEM signals[] = 
{ 0b00000110,
  0b00000110,
  0b00110110,
  0b00110110,
  0b10110110,
  0b10110110,
  0b10110110 };
