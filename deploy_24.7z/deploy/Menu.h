#define MNU_MAIN 0
#define MNU_DATA 1
#define MNU_WAYP 2
#define MNU_FILE 3

void mainMenu() {

  oled.clearDisplay();
  oled.setCursor(0, 0);
  oled.println(F("Main Menu"));
  oled.setCursor(10, 20);
  oled.println(F("Data Logger"));
  oled.setCursor(10, 30);
  oled.println(F("Waypoints"));
  oled.setCursor(10, 40);
  oled.println(F("File System"));
  oled.setCursor(0, 20+sel*10);
  oled.print(F(">"));
  oled.display();
  
}

void wayPointMenu(){

  if ( ( millis() - lastDebounceTime > 250 ) && !digitalRead(BTN_NEXT) && mnu == MNU_WAYP){
      if (wpPage < 2) wpPage++;
      else wpPage = 0;
      lastDebounceTime = millis(); 
    }

  oled.clearDisplay();
  for (int i = 0; i<3; i++){
    char str[128];
    uint8_t j = (wpPage * 3) + i;
    float wpAir = TinyGPSPlus::distanceBetween(gps.location.lat(), gps.location.lng(), wpPoints[j][0], wpPoints[j][1]) / 1000.0;
    float wpTar = TinyGPSPlus::courseTo( gps.location.lat(), gps.location.lng(), wpPoints[j][0], wpPoints[j][1]);
    oled.setCursor(0, i*22);
    oled.print(wpNames[j]);
    sprintf(str, "%.2fkm %.2f%c", wpAir, wpTar, 248);
    oled.setCursor(7, (i*22+9));
    oled.print(str);
  }

  oled.display();
}

void fileDownloadMenu(){

  oled.clearDisplay();
  oled.setCursor(0, 0);
  oled.print(F("Free mem : "));
  oled.print(( (SPIFFS.totalBytes() - SPIFFS.usedBytes()) / 1024.0) );
  oled.print(" kB");

  WiFi.softAP(ssid, pass);
  IPAddress myIP = WiFi.softAPIP();
  oled.setCursor(0, 20);
  oled.print(F("AP IP Address: "));
  oled.print(myIP);
  oled.display();

  server.on("/download", HTTP_GET, [](AsyncWebServerRequest * request){
    request->send(SPIFFS, "/log.txt", "text/html", true);
    oled.print("/nSending File...");
    oled.display();
  });

  server.begin();
}
